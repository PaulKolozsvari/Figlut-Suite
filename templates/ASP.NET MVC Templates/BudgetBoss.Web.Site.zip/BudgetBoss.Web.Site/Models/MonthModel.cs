﻿namespace BudgetBoss.Web.Site.Models
{
    #region Using Directives

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using BudgetBoss.ORM;
    using Figlut.Server.Toolkit.Data;
    using Figlut.Server.Toolkit.Web.MVC.Models;
    using BudgetBoss.Data;
    using Figlut.Server.Toolkit.Utilities;

    #endregion //Using Directives

    public class MonthModel : FiglutEntityModel
    {
        #region Constructors

        public MonthModel()
        {
        }

        public MonthModel(Month e)
        {
            DataValidator.ValidateObjectNotNull(e, nameof(e), nameof(MonthModel));
            CopyPropertiesFrom(e);
        }

        #endregion //Constructors

        #region Properties

        public Guid MonthId { get; set; }

        public MonthName Name { get; set; }

        public int MonthNumber { get; set; }

        public int Year { get; set; }

        public DateTime DateCreated { get; set; }

        #endregion //Properties

        #region Methods

        public void CopyPropertiesFrom(Month e)
        {
            this.MonthId = e.MonthId;
            this.Name = EnumHelper.GetEnumFromString<MonthName>(e.Name, MonthName.None);
            this.MonthNumber = e.MonthNumber;
            this.Year = e.Year;
            this.DateCreated = e.DateCreated;
        }

        public void CopyPropertiesTo(Month e)
        {
            e.MonthId = this.MonthId;
            e.Name = this.Name.ToString(); ;
            e.MonthNumber = this.MonthNumber;
            e.Year = this.Year;
            e.DateCreated = this.DateCreated;
        }

        public override bool IsValid(out string errorMessage)
        {
            if (this.Name == MonthName.None)
            {
                errorMessage = $"{EntityReader<MonthModel>.GetPropertyName(p => p.Name, true)} not selected.";
                return false;
            }
            if (!IsIntFieldWithinRange(EntityReader<MonthModel>.GetPropertyName(p => p.MonthNumber, true), this.MonthNumber, 1, 12, out errorMessage))
            {
                return false;
            }
            if (!IsIntFieldNotNegative(EntityReader<MonthModel>.GetPropertyName(p => p.Year, true), this.Year, out errorMessage))
            {
                return false;
            }
            if (!IsDateFieldSet(EntityReader<MonthModel>.GetPropertyName(p => p.DateCreated, true), this.DateCreated, out errorMessage))
            {
                return false;
            }
            return true;
        }

        #endregion //Methods
    }
}