﻿namespace BudgetBoss.Web.Site.Configuration
{
    #region Using Directives

    using Figlut.Server.Toolkit.Utilities.SettingsFile.Default;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    #endregion //Using Directives

    public class BBWebSettings : DatabaseAppSettings
    {
        #region Application Settings

        public bool DisableScreenScalingForMobileDevices { get; set; }

        #endregion //Application Settings
    }
}