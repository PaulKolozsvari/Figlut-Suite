﻿namespace BudgetBoss.Web.Site.Controllers
{
    #region Using Directives

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Figlut.Server.Toolkit.Web.MVC.Controllers;
    using Figlut.Server.Toolkit.Utilities;
    using Figlut.Server.Toolkit.Web.MVC.Models;

    #endregion //Using Directives

    public class BBController : FiglutController
    {
        #region Methods

        protected virtual RedirectToRouteResult HandleException(Exception ex)
        {
            ExceptionHandler.HandleException(ex);
            return RedirectToError(ex.Message);
        }

        protected virtual void SetViewBagSearchFieldIdentifier<T>(FilterModel<T> model) where T :class
        {
            ViewBag.SearchFieldIdentifier = model.SearchFieldIdentifier;
        }

        #endregion //Methods
    }
}