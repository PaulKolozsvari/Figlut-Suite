﻿namespace BudgetBoss.Web.Site.Controllers
{
    #region Using Directives

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Figlut.Server.Toolkit.Web.MVC.Controllers;
    using Figlut.Server.Toolkit.Web.MVC.Models;
    using BudgetBoss.ORM;
    using BudgetBoss.Data;
    using Figlut.Server.Toolkit.Utilities;
    using BudgetBoss.Web.Site.Models;
    using Figlut.Server.Toolkit.Data;
    using BudgetBoss.ORM.Csv;

    #endregion //Using Directives

    public class MonthController : BBController
    {
        #region Constants

        private const string MONTH_GRID_PARTIAL_VIEW_NAME = "_MonthGrid";
        private const string EDIT_MONTH_DIALOG_PARTIAL_VIEW_NAME = "_EditMonthDialog";

        #endregion //Constants

        #region Methods

        public FilterModel<MonthModel> GetMonthsFilterModel(BBContext context, FilterModel<MonthModel> model)
        {
            context = context ?? BBContext.Create();
            model.IsAdministrator = false;
            List<Month> entities = context.GetMonthsByFilter(model.SearchText);
            List<MonthModel> resultModel = new List<MonthModel>();
            entities.ForEach(p => resultModel.Add(new MonthModel(p)));
            model.DataModel.Clear();
            model.DataModel = resultModel;
            model.TotalTableCount = context.GetAllMonthsCount();
            return model;
        }

        private void RefreshMonthsDropDownList(MonthModel model)
        {
            List<SelectListItem> monthNames = new List<SelectListItem>();
            Array monthNameValues = EnumHelper.GetEnumValues(typeof(MonthName));
            for (int i = 0; i < monthNameValues.Length; i++)
            {
                string monthNameText = monthNameValues.GetValue(i).ToString();
                MonthName monthName = (MonthName)Enum.Parse(typeof(MonthName), monthNameText);
                int monthNameId = (int)monthName;
                monthNames.Add(new SelectListItem()
                {
                    Text = monthNameText,
                    Value = monthNameText,
                    Selected = model != null ? (model.Name.ToString() == monthNameText) : false
                });
            }
            ViewBag.MonthList = monthNames;
        }

        #endregion //Methods

        #region Actions

        public ActionResult Index()
        {
            try
            {
                BBContext context = BBContext.Create();
                FilterModel<MonthModel> model = GetMonthsFilterModel(context, new FilterModel<MonthModel>());
                if (model == null) //There was an error and ViewBag.ErrorMessage has been set. So just return an empty model.
                {
                    return View(new FilterModel<Month>());
                }
                SetViewBagSearchFieldIdentifier<MonthModel>(model);
                return View(model);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        [HttpPost]
        public ActionResult Index(FilterModel<MonthModel> model)
        {
            try
            {
                BBContext context = BBContext.Create();
                SetViewBagSearchFieldIdentifier<MonthModel>(model);
                FilterModel<MonthModel> resultModel = GetMonthsFilterModel(context, model);
                if (resultModel == null) //There was an error and ViewBag.ErrorMessage has been set. So just return an empty model.
                {
                    return PartialView(MONTH_GRID_PARTIAL_VIEW_NAME, new FilterModel<MonthModel>());
                }
                return PartialView(MONTH_GRID_PARTIAL_VIEW_NAME, resultModel);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        public ActionResult EditDialog(Nullable<Guid> monthId)
        {
            try
            {
                BBContext context = BBContext.Create();
                if (!monthId.HasValue)
                {
                    return PartialView(EDIT_MONTH_DIALOG_PARTIAL_VIEW_NAME, new MonthModel());
                }
                Month e = context.GetEntityBySurrogateKey<Month>(monthId.Value, false);
                MonthModel model = new MonthModel(e);
                RefreshMonthsDropDownList(model);
                PartialViewResult result = PartialView(EDIT_MONTH_DIALOG_PARTIAL_VIEW_NAME, model);
                return result;
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        [HttpPost]
        public ActionResult EditDialog(MonthModel model)
        {
            try
            {
                BBContext context = BBContext.Create();
                RefreshMonthsDropDownList(model);
                string errorMessage = null;
                if (!model.IsValid(out errorMessage))
                {
                    return GetJsonResult(false, errorMessage);
                }
                Month e = context.GetEntityBySurrogateKey<Month>(model.MonthId, false);
                model.CopyPropertiesTo(e);
                context.DB.SubmitChanges();
                return GetJsonResult(true);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        [HttpPost]
        public ActionResult Delete(Guid monthId)
        {
            try
            {
                BBContext context = BBContext.Create();
                Month e = context.GetEntityBySurrogateKey<Month>(monthId, false);
                context.Delete<Month>(e);
                return GetJsonResult(true);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        public ActionResult ConfirmDeleteDialog(Guid identifier)
        {
            try
            {
                BBContext context = BBContext.Create();
                Month e = context.GetEntityBySurrogateKey<Month>(identifier, false);
                ConfirmationModel model = new ConfirmationModel();
                model.PostBackControllerAction = GetCurrentActionName();
                model.PostBackControllerName = GetCurrentControllerName();
                model.DialogDivId = CONFIRMATION_DIALOG_DIV_ID;
                if (e != null)
                {
                    model.Identifier = identifier;
                    model.ConfirmationMessage = $"Delete {nameof(Month)} '{e.Name}'?";
                }
                PartialViewResult result = PartialView(CONFIRMATION_DIALOG_PARTIAL_VIEW_NAME, model);
                return result;
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        [HttpPost]
        public ActionResult ConfirmDeleteDialog(ConfirmationModel model)
        {
            try
            {
                BBContext context = BBContext.Create();
                Month e = context.GetEntityBySurrogateKey<Month>(model.Identifier, false);
                context.Delete<Month>(e);
                return GetJsonResult(true);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        public ActionResult ConfirmDeleteAllDialog(string searchParametersString)
        {
            try
            {
                BBContext context = BBContext.Create();
                ConfirmationModel model = new ConfirmationModel();
                model.PostBackControllerAction = GetCurrentActionName();
                model.PostBackControllerName = GetCurrentControllerName();
                model.DialogDivId = CONFIRMATION_DIALOG_DIV_ID;

                string[] searchParameters;
                string searchText;
                GetConfirmationModelFromSearchParametersString(searchParametersString, out searchParameters, out searchText);
                model.SearchText = searchText;
                model.ConfirmationMessage = $"Delete all {nameof(Month)}s currently loaded?";
                PartialViewResult result = PartialView(CONFIRMATION_DIALOG_PARTIAL_VIEW_NAME, model);
                return result;
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        [HttpPost]
        public ActionResult ConfirmDeleteAllDialog(ConfirmationModel model)
        {
            try
            {
                BBContext context = BBContext.Create();
                context.DeleteMonthsByFilter(model.SearchText);
                return GetJsonResult(true);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        public ActionResult DownloadCsvFile(string searchParametersString)
        {
            try
            {
                BBContext context = BBContext.Create();
                GetConfirmationModelFromSearchParametersString(searchParametersString, out string[] searchParameters, out string searchText);
                List<Month> entities = context.GetMonthsByFilter(searchText);
                EntityCache<Guid, MonthCsv> cache = new EntityCache<Guid, MonthCsv>();
                entities.ForEach(p => cache.Add(p.MonthId, new MonthCsv(p)));
                return GetCsvFileResult<MonthCsv>(cache);
            }
            catch (Exception ex)
            {
                return HandleException(ex);
            }
        }

        #endregion //Actions
    }
}